class IndividualCustomer : Customer
{
    public string DateOfBirth { get; set; }
    public string Gender { get; set; }
}