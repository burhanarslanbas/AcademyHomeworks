﻿namespace PairHomeworkOOP1
{
    class Customer
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}